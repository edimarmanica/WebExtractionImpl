/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edimarmanica.extractionrules.neo4j;

import org.neo4j.graphdb.RelationshipType;

/**
 *
 * @author edimar
 */
 enum RelTypes implements RelationshipType {
    has_child
}
