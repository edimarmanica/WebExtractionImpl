/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edimarmanica.extractionrules.load;

import br.edimarmanica.extractionrules.Config;

/**
 *
 * @author edimar
 */
public class FormatTextNode {
    
    public static String format(String value) throws InvalidTextNode{
        check(value);
        
        //remove extra spaces
        String ret = value.replaceAll("\\s\\s+", " ").trim();      
        
        return ret;
    }
    
    public static void check(String value) throws InvalidTextNode{
        
        String ret = value.replaceAll("\\s\\s+", " ").trim();
        
        //nada
        if (ret.isEmpty()){
            throw new InvalidTextNode(value);
        }
        
        //muito grande
        if (ret.length() > Config.TEXT_NODE_MAX_LENGHT){
            throw new InvalidTextNode(value);
        }
        
        //sem dígito ou letra
        if (!ret.matches(".*(\\d|[a-zA-Z]).*")){
            throw new InvalidTextNode(value);
        }
    }
}
