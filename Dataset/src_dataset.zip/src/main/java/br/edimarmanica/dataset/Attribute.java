/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edimarmanica.dataset;

/**
 *
 * @author edimar
 */
public interface Attribute {

    public String getAttributeID();

    public String getAttributeIDbyDataset();
}
