/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edimarmanica.dataset;

/**
 *
 * @author edimar
 */
public class Configuration {
    public static final String PATH_BASE = "/media/Dados/bases/";
    public static final String PATH_EXPRESSIVENESS = "/media/Dados/dropbox/linux/Dropbox/doutorado04/expressividade/";
}
